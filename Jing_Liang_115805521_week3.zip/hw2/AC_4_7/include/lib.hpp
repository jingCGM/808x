#pragma once

#include<iostream>

void dummy()
{
    std::cout << "HI" << std::endl;
}
