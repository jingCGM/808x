/**
 *  @file    main.cpp
 *  @author  Jing Liang
 *  @copyright 3-clause BSD
 *  @date    09/14/2019
 *  @version 1.0
 *
 *  @brief ENPM808X
 *
 *  @section DESCRIPTION
 *
 *  This program use function to calculate the average of the numbers stored in a vector<double>
 *
 */

#include <unordered_map>
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <boost/algorithm/string/predicate.hpp>
#include <cstdlib>


/**
 * @brief    collectNumbers function read double type numbers and return them as a vector
 * @param    None
 * @return   a vector of double type numbers
 */
std::vector<double> collectNumbers(){
	std::vector<double>	numberVector;  					// vector to store words
	std::string			continueInputInformation="yes";	// it is used to decide if enter student's information

	while(boost::iequals(continueInputInformation, "yes")){
		double number;			   // the number from iostream

		while(1){
			// ask for and read numbers
			std::string readString;				// It's going to store read string
			std::cout << "Please enter one number: ";
			std::cin>>readString;
			std::cin.ignore();

			try{
				number = std::strtod(readString.c_str(),NULL);
				break;
			}
			catch(const std::invalid_argument& ia) {
				std::cerr << "Invalid argument: " << ia.what() << '\n';
				continue;
			}
			catch (const std::out_of_range& oor) {
			    std::cerr << "Out of Range error: " << oor.what() << '\n';
			    continue;
			}
		}

		numberVector.push_back(number);

		std::cout<< "Continue enter number? (yes/no) "<<std::endl;
		std::cin >> continueInputInformation;
		std::cin.ignore();
	}
	return numberVector;
}


/**
 * @brief    showNumbers function, which can show the numbers in vector of double type
 * @param    a vector of double type
 * @return   none
 */
void showNumbers (const std::vector <double> v){
    std::cout<<"The numbers are: ";
	for (auto& d : v){
   	   std::cout << d<<", ";
    }
    std::cout<< std::endl;
}

/**
 * @brief    calculateSum function, which can calculate the average of numbers in vector of double type
 * @param    a vector of double type
 * @return   double
 */
double calculateAverage (const std::vector <double> v){
    double average=0;
	for (auto& d : v){
   	   average +=d;
    }
	average /= v.size();
    return average;
}

/**
 * @brief    main function
 * @param    argc int
 * @param    argv char array
 * @return   0
 */
int main(int argc, char* argv[])
{
	std::vector<double> readNumber = collectNumbers();
	showNumbers(readNumber);
	std::cout<<"average value is: "<<calculateAverage(readNumber)<<std::endl;
	return 0;
}
