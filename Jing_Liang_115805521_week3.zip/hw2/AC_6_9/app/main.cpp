/**
 *  @file    main.cpp
 *  @author  Jing Liang
 *  @copyright 3-clause BSD
 *  @date    01/01/2019
 *  @version 1.0
 *
 *  @brief ENPM808X
 *
 *  @section DESCRIPTION
 *
 *  This program use function to read words from an input stream and stores them in a vector .
 *  Use that function both to write programs that count the number of words in the input,
 *  and to count how many times each word occurred.
 */

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <boost/algorithm/string/predicate.hpp>
#include <numeric>
#include <functional>
#include <iterator>

/**
 * @brief    collectWords function, which can collect setences from iostream, and return back a vector containing all setences user entered
 * @param    none
 * @return   a vector of all entered words
 */
std::vector<std::string> collectWords()
{
	std::vector<std::string>	wordsVector;  				// vector to store words
	std::string		continueInputInformation="yes";	 		// it is used to decide if enter student's information

	while(boost::iequals(continueInputInformation, "yes")){
		std::string	recheckTag = "no"; // the string value checks if the input data is same as what user wants.
		std::string words;			   // the words from iostream

		while(boost::iequals(recheckTag, "no")){
			words.clear();
			// ask for and read words
			std::cout << "Please enter your text: ";
			std::getline (std::cin,words);

			// check if the input has no words
			while(words.size()==0){
				std::cout<<"no words detected, please re-enter words. "<<std::endl;
				std::getline (std::cin,words);
			}

			// print out and check if the words entered is right
			recheckTag.clear();
			std::cout << "you entered:\"" << words <<"\"  is this right? (yes/no)";
			std::cin >> recheckTag;
			std::cin.ignore();
		}

		wordsVector.push_back(words);

		std::cout<< "Continue enter words? (yes/no) "<<std::endl;
		std::cin >> continueInputInformation;
		std::cin.ignore();
	}
	return wordsVector;
}

/**
 * @brief    showWords function, which can show the words in vector of strings
 * @param    a vector of strings
 * @return   none
 */
void showWords (const std::vector <std::string> v){
     for (auto& s : v){
   	   std::cout << s << std::endl;
     }
}

/**
 * @brief    concatenateStrings function, which can concatenate all strings in a vector and print it out
 * @param    a vector of strings
 * @return   std::string
 */
std::string concatenateStrings(const std::vector <std::string> v){

	//BinaryOperation used to add strings together
	auto stringAdd = [](std::string a, std::string b) {return a+b;};

	// accumulate is in library of algorithm, use it to concatenate all strings together
	std::string empty="";
	std::string totalString = std::accumulate(v.begin(), v.end(),empty,stringAdd);
	return totalString;
}

/**
 * @brief    main function
 * @param    argc int
 * @param    argv char array
 * @return   0
 */
int main(int argc, char* argv[])
{

	std::vector<std::string>	collectedWordsVector = collectWords();

	//print out all the words in vector of words
	showWords(collectedWordsVector);

	//concatenate all strings in vector together
	std::string afterConcatenation = concatenateStrings(collectedWordsVector);
	std::cout<<"the total string is: \""<<afterConcatenation<<"\""<<std::endl;

	return 0;
}
