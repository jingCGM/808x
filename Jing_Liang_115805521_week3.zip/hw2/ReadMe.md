Each folder has the format AC/SE_x_x contains one question

AC: accelerated cpp
SE: Software Engineering: The Curren Practice

_A_B: question A.B
	
e.g. AC_4_5: question 4.5 in textbook, accelerated cpp.


folder writing_part_pdf:
	Answer.pdf: answers of writing part questions
	all other images are refered in the Answer.pdf file.