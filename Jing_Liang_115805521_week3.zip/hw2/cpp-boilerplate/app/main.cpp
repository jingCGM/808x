#include <iostream>
#include <lib.hpp>

int main()
{
    dummy();
    return 0;
}
