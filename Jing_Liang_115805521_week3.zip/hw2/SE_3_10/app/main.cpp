/**
 *  @file    main.cpp
 *  @author  Jing Liang
 *  @copyright 3-clause BSD
 *  @date    01/01/2019
 *  @version 1.0
 *
 *  @brief ENPM808X
 *
 *  @section DESCRIPTION
 *
 *  This program use a class that supports course grading; the class contains an vector where each student is identified by an integer and has a course grade.
 *  There is also a method that can change the student grade and a method that computes the grade point average for the class.
 */

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <boost/algorithm/string/predicate.hpp>
#include <numeric>
#include <functional>
#include <iterator>


/**
 * @brief	class of student store student id and grade, also provide a function to change student grade.
 */
class student{
public:
    int id=0;
    double grade=0;

    /**
     * @brief    constructor of student class
     * @param    givenID int
     * @param	 givenGrade double
     * @return   none
     */
    student(int givenID, double givenGrade){
    	id = givenID;
    	grade = givenGrade;
    }
    student(){}
};



/**
 * @brief	class of course contain multiple students, which is represent by a vector of student class.
 * 			It also provide functions to compute average grade of the whole course, get grade of certain student, and also provide a function to change students' grades.
 */
class course{
public:
    std::vector<student> people;
    double computeAverageGrade();
    double getGrade(int id);
    bool changeStudentGrade(int id, double newGrade);

};

/**
 * @brief    the function is used to compute average grade of the whole course
 * @param    none
 * @return   averaged grade double
 */
double course::computeAverageGrade(){
	double totalGrade = 0;
    for(student person:people){
        totalGrade +=person.grade;
    }
    return totalGrade/people.size();
}

/**
 * @brief    the function is used to change student's grade by providing student id and new grade
 * @param    requiredID int
 * @param	 newGrade double
 * @return   success bool
 */
bool course::changeStudentGrade(int requiredID, double newGrade){
	bool success = false;
    for(student &person:people){
        if(person.id==requiredID){
            person.grade = newGrade;
            success = true;
        }
    }
    return success;
}

/**
 * @brief    the function is used to get grade of certain student with given ID
 * @param    requiredID int
 * @return   required grade double
 */
double course::getGrade(int requiredID){
	double requiredGrade=0.0;
    for(student &person:people){
        if(person.id==requiredID){
            requiredGrade = person.grade;
        }
    }
    return requiredGrade;
}

/**
 * @brief    the function is to read student record as a student account
 * @param    newStudent reference student class
 * @return   success bool
 */
bool readStudentRecord(student& newStudent){
	bool success=false;

	// ask for and read the student's id and grade
	int studentID;
	double grade;
	bool conditionValue = true;
	while(conditionValue){
		std::string readString;
		std::cout << "Please enter your ID: ";
		std::cin>>readString;
		std::cin.ignore();

		try{
			studentID = std::stoi(readString);
			break;
		}
		catch(const std::invalid_argument& ia) {
			std::cerr << "Invalid argument: " << ia.what() << '\n';
			continue;
		}
		catch (const std::out_of_range& oor) {
			std::cerr << "Out of Range error: " << oor.what() << '\n';
			continue;
		}
	}

	//read student's grade
	while(1){

		std::string readString;				// It's going to store read string
		std::cout << "Please enter your grade: ";
		std::cin>>readString;
		std::cin.ignore();

		try{
			grade = std::strtod(readString.c_str(),NULL);
			break;
		}
		catch(const std::invalid_argument& ia) {
			std::cerr << "Invalid argument: " << ia.what() << '\n';
			continue;
		}
		catch (const std::out_of_range& oor) {
			std::cerr << "Out of Range error: " << oor.what() << '\n';
			continue;
		}
	}

	std::string determineInformation; //It is used to determine if the information is correct
	std::cout<<"your ID is: "<<studentID<<", your grade is: "<<grade<<", Information correct? (yes/no)"<<std::endl;
	std::cin>>determineInformation;
	std::cin.ignore();
	if(boost::iequals(determineInformation, "yes"))
	{
		newStudent.id = studentID;
		newStudent.grade=grade;
		success=true;
	}
	else{success=false;}
	return success;
}


/**
 * @brief    the function is used to add students' account to course
 * @param    newCourse  reference of course class
 * @return   none
 */
void readCourseRecord(course& newCourse)
{
	std::string		continueInputInformation="yes";	 // it is used to decide if enter student's information

	while(boost::iequals(continueInputInformation, "yes")){

		student	newStudent;	// create a new student account
		if(readStudentRecord(newStudent)){
			if( newCourse.changeStudentGrade(newStudent.id,newStudent.grade) ){
				std::cout<<"successfully changed student information"<<std::endl;
			}
			else {
				newCourse.people.push_back(newStudent);
			}
		}

		std::cout<< "Continue enter student's information? (yes/no) "<<std::endl;
		std::cin >> continueInputInformation;
		std::cin.ignore();
	}
}

/**
 * @brief    the function is used to change student's account
 * @param    newCourse  reference of course class
 * @return   none
 */
void changeStudentsRecord(course& newCourse)
{
	std::string		continueInputInformation="yes";	 // it is used to decide if enter student's information

	std::cout<< "Need to change student's information? (yes/no) "<<std::endl;
	std::cin >> continueInputInformation;
	std::cin.ignore();

	while(boost::iequals(continueInputInformation, "yes")){

		student	newStudent;	// create a new student account
		if(readStudentRecord(newStudent)){
			if( newCourse.changeStudentGrade(newStudent.id,newStudent.grade) ){
				std::cout<<"successfully changed"<<std::endl;
			}
			else {
				std::cout<<"no such student"<<std::endl;
			}
		}

		std::cout<< "Continue change student's information? (yes/no) "<<std::endl;
		std::cin >> continueInputInformation;
		std::cin.ignore();
	}
}

/**
 * @brief    the function is used to show all students' information
 * @param    newCourse  reference of course class
 * @return   none
 */
void showAllInformation(course& newCourse)
{
	for(student &person:newCourse.people){
		std::cout<<"ID: "<<person.id<<", grade:"<<person.grade<<std::endl;
	}
}
/**
 * @brief    main function
 * @param    argc int
 * @param    argv char array
 * @return   0
 */
int main(int argc, const char* argv[])
{
	course enpm808x;		//create a course class

	readCourseRecord(enpm808x);			//read students' record from std::cin

	std::cout << "average grade: "<<enpm808x.computeAverageGrade()<<std::endl;	//show averaged grade of the course

	showAllInformation(enpm808x);		//show information of the course

	changeStudentsRecord(enpm808x);		//change student record

	showAllInformation(enpm808x);		//show information of the course
	return 0;
}
