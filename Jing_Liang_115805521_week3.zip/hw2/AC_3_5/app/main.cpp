/**
 *  @file    main.cpp
 *  @author  Jing Liang
 *  @copyright 3-clause BSD
 *  @date    01/01/2019
 *  @version 1.0
 *
 *  @brief ENPM808X
 *
 *  @section DESCRIPTION
 *
 *  This program could keep two vector s in sync: The first should hold the student's names,
 *  and the second the final grades that can be computed as input is read.
 */

//#include <algorithm>
#include <iomanip>
//#include <ios>
#include <iostream>
#include <string>
#include <vector>
#include <boost/algorithm/string/predicate.hpp>


/**
 * @brief    main function
 * @param    argc int
 * @param    argv char array
 * @return   0
 */
int main(int argc, char* argv[])
{
	std::vector<std::string>	nameVector;  				// students' names
	std::vector<double> 		gradeVector;  				// students' grades
	std::string		continueInputInformation="yes";	 // it is used to decide if enter student's information

	while(boost::iequals(continueInputInformation, "yes")){
		// ask for and read the student's name
		std::cout << "Please enter your name: ";
		std::string studentName;
		std::getline (std::cin,studentName);
		std::cout << "Hi, " << studentName << "!" << std::endl;
		while(studentName.size()==0){
			std::cout << "name format is wrong, Please enter your name again: ";
			std::getline (std::cin,studentName);
		}

		// ask for and read the student's grade
		std::cout << "Please enter your grade: ";
		double grade;
		std::cin >> grade;

		nameVector.push_back(studentName);
		gradeVector.push_back(grade);

		std::cout<< "Continue enter student's information? (yes/no) "<<std::endl;
		std::cin >> continueInputInformation;
		std::cin.ignore();
	}

	//print out the names and scores
	for(uint index=0;index<nameVector.size();index++){
		std::streamsize prec = std::cout.precision();
		std::cout<<nameVector[index]<<"'s grade is "<< std::setprecision(3)<<gradeVector[index]<< std::setprecision(prec)<<std::endl;
	}
	return 0;
}
